This is a package with GLUT for Mingw32.
Copy glut32.dll to somewhere in your PATH like c:\windows\system.
The files in the include and lib directories should be moved to the usual places.

glut32.dll is from the GLUT 3.7.3 distribution and the import library libglut32.a was 
created with the reimp tool. 
You can find makefiles for the libraries and samples at the GLUT section of :
http://sites.netscape.net/zaqhaq/
Here is also some additional information and links to documentation.
