# A HTML Assignment 1

Your job is to create a web site that shows the following elements. Make sure all of your code is arranged properly and cleanly. This is comparable to a test so I will NOT be giving very much help if any. For this first assignment you will have the tutorial to use for help, so it will be your main tool.

All of this information can be found in HTML
Make sure your page has some kind of common theme/topic, not just random stuff!
Your page must contain the following:
1. Basic Tags: Make sure you have your document set as HTML and have a body of the
page defined.
2. Background: Set a background color or a background image
3. Font = Font in bold, italics and underlined as well as showing different types of fonts
and different font colors and sizes. You can do this as you fill out your page content.
4. Headings: Your page should have at least TWO different headings of different types.
The main heading should be aligned to the center of the page.
5. Lists: You need ONE of each type of list on your page. Ordered, unordered, and
definition list.
6. Misc: I want to see at least TWO different horizontal dividing lines. Also use line
breaks <Br> when necessary