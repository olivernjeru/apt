Python 3.8.2 (tags/v3.8.2:7b3ab59, Feb 25 2020, 22:45:29) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 3 +7
10
>>> 8 + f
Traceback (most recent call last):
  File "<pyshell#1>", line 1, in <module>
    8 + f
NameError: name 'f' is not defined
>>>  3 + 7
 
SyntaxError: unexpected indent
>>> 3/2
1.5
>>> 3/0
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
    3/0
ZeroDivisionError: division by zero
>>> 