first = float(input("Enter the first number: "))
second = float(input("Enter the second number: "))
print("The sum is", first + second)
