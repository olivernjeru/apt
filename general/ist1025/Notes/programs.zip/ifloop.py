for number in range(100):
    if number % 7 == 0 or number % 3 == 0:
        print(number, "is divisble by 3 or 7.")
    else:
        print(number, "is not divisible by 3 or 7.")
