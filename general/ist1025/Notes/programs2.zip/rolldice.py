import random
for roll in range(10):
    r = random.randint(1, 6)
    print(r, end = " ")
